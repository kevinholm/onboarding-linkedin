# Executive Talent Platform - epics, user stories og acceptkriterier

## Produktprincip
Platformen skal som udgangspunkt automatisere alt gentageligt digitalt arbejde i agentprocessen. Den menneskelige agent er et human-on-top lag, der prioriterer, godkender, finjusterer og traeder ind ved undtagelser, relationstunge dialoger, high-stakes beslutninger og manglende respons.

## Epic 1 - Opportunity ingestion og bevaring af kildemateriale

### User story 1.1
Som agent vil jeg have, at et job eller brief automatisk bliver oprettet som en struktureret opportunity, saa vi altid kan arbejde videre med den samme kilde i platformen.

**Acceptkriterier**
- Naar et link indsattes, henter systemet automatisk opslaget ned og gemmer originalkilde, snapshot og struktureret version.
- Naar et PDF-brief uploades, gemmes originalfil og udtrukket, soegbar tekstversion.
- Opportunity kan ikke oprettes uden minimum originalkilde eller uploadet brief.
- Alle opportunities har source type, source URL eller upload reference, timestamp og versionshistorik.

### User story 1.2
Som agent vil jeg kunne stole paa, at opslaget stadig findes i platformen, selv hvis den eksterne annonce forsvinder.

**Acceptkriterier**
- Snapshot og metadata kan vises direkte i opportunity-visningen.
- Seneste og tidligere versioner kan sammenlignes.
- Systemet markerer hvis en kilde senere er blevet utilgaengelig eller aendret.

## Epic 2 - AI-jobanalyse og company intelligence

### User story 2.1
Som agent vil jeg automatisk have en AI-baseret analyse af stilling og virksomhed, saa jeg hurtigt forstaar hvad rollen reelt handler om.

**Acceptkriterier**
- Ny opportunity udloeser automatisk jobanalyse uden manuel handling.
- Analysen indeholder rolleformål, ansvar, succeskriterier, must-have/nice-to-have og forventede stakeholders.
- Analysen indeholder company intelligence som branche, ejerskab, størrelse, organisationsform og relevante transformationssignaler.
- Agenten kan se hvilke kilder analysen bygger paa.

### User story 2.2
Som agent vil jeg kunne redigere eller overstyre analysen, saa jeg kan bruge min egen judgement.

**Acceptkriterier**
- AI-output kan redigeres og gemmes som en ny version.
- Systemet bevarer baade original AI-version og agentens redigerede version.
- Overstyringer logges i audit trail.

## Epic 3 - Match, positionering og next best action

### User story 3.1
Som agent vil jeg have automatiske matchscorer og positioneringsforslag, saa jeg hurtigt kan se hvilke kandidater der er mest relevante.

**Acceptkriterier**
- Systemet opretter match-records med score og forklarlige delkomponenter.
- Matchforklaring viser styrker, gap og positioneringsvinkel.
- Systemet foreslaar next best action pr. kandidat og opportunity.
- Agenten kan manuelt op- eller nedprioritere et match.

### User story 3.2
Som kandidat vil jeg have en kort forklaring paa hvorfor et job er relevant, saa jeg kan tage stilling hurtigt.

**Acceptkriterier**
- Kandidaten ser en kort matchforklaring med noegleargumenter.
- Kandidaten kan acceptere, afvise eller snooze en matchmulighed.
- Kandidatens valg fodres tilbage til ranking- og praeferencehistorik.

## Epic 4 - Automatiseret dokument- og materialeproduktion

### User story 4.1
Som agent vil jeg have, at platformen automatisk genererer et målrettet CV, pitch og andet materiale, saa manuel kladdeproduktion minimeres.

**Acceptkriterier**
- Godkendt opportunity kan udloese automatisk generering af CV-version, introtekst, pitch og prep-pack.
- Materialer versioneres og knyttes til den konkrete opportunity og kandidat.
- Agent og kandidat kan redigere materialet foer ekstern brug.
- Systemet viser forskel mellem masterprofil og opportunity-specifik version.

### User story 4.2
Som kandidat vil jeg bevare kontrol over min masterprofil, saa AI ikke omskriver den uden min accept.

**Acceptkriterier**
- Masterprofilen kan kun opdateres via eksplicit godkendelse.
- AI-forslag til masterprofil vises som forslag og ikke som automatisk overskrivning.
- Kandidaten kan acceptere, afvise eller redigere hvert forslag.

## Epic 5 - Outreach fra agentens mailadresse, reply-tracking og eskalering

### User story 5.1
Som agent vil jeg have, at platformen kan sende outreach fra min egen mailadresse, saa modtagere svarer til mig og ikke til en no-reply konto.

**Acceptkriterier**
- Systemet understoetter delegated send eller send-as via agentens mailbox.
- Udgaaende beskeder bliver logget paa den relevante case.
- Indgaaende svar kobles tilbage til den rigtige thread og case.
- Agenten kan se beskedhistorik, status og timing i cockpit.

### User story 5.2
Som agent vil jeg have automatiske opfoelgninger, men blive notificeret naar en relation kraever min personlige handling.

**Acceptkriterier**
- Systemet kan starte en konfigurerbar follow-up sekvens pr. case.
- Ingen respons inden SLA skaber en task til agenten med anbefalet handling.
- Positiv respons, booking eller high-value reply giver instant notifikation.
- Agenten kan pause, omskrive eller stoppe sekvensen manuelt.

## Epic 6 - Human-on-top cockpit, notifikationer og exception handling

### User story 6.1
Som agent vil jeg have et cockpit der proaktivt fortaeller mig, hvornår jeg skal traede til, saa jeg kun bruger tid hvor menneskelig indsats skaber mest vaerdi.

**Acceptkriterier**
- Cockpittet viser tasks, alerts, SLA-brud, manglende respons, fortrolige cases og manuelle review-behov.
- Hver alert viser anbefalet next best action og hvorfor systemet eskalerer.
- Agenten kan markere en task som udfoert, udsat eller overstyret.
- Alle manuelle beslutninger gemmes i audit trail.

### User story 6.2
Som operations- eller admin-bruger vil jeg kunne styre hvilke flows der er fuldautomatiske, semi-automatiske eller manuelle, saa graden af automation kan justeres over tid.

**Acceptkriterier**
- Hvert workflow kan konfigureres med release policy, SLA og eskaleringsregler.
- High-stakes flows kan kraeve manuel godkendelse foer ekstern udsendelse.
- Standardflows kan koere automatisk uden agent-review.
- Konfigurationsaendringer er versionsstyrede og auditerbare.

## Epic 7 - Fortrolige briefs og kontrolleret reveal

### User story 7.1
Som partner eller agent vil jeg kunne arbejde med fortrolige briefs uden at brede informationen unodigt ud, saa platformen kan bruges til search og sensitive mandater.

**Acceptkriterier**
- Originalbrief kan gemmes i sealed storage med need-to-know adgang.
- Systemet genererer en sanitiseret kravreprasentation til matching.
- Reveal af fuldt brief eller kandidatidentitet kan kraeve NDA og eksplicit godkendelse.
- Alle reveal-haendelser logges.

## Epic 8 - Laering, feedback og kontinuerlig forbedring

### User story 8.1
Som produktteam vil jeg have feedback loops ind i systemet, saa automationen bliver bedre over tid.

**Acceptkriterier**
- Afvisninger, snooze, reply-typer og procesudfald gemmes struktureret.
- Agentfeedback kan bruges som traenings- og regelinput.
- Dashboard eller eksport kan vise hvilke outreach- og matchmoenstre der performer bedst.
- Historik kan bruges til at justere thresholds og next best action-logik.
