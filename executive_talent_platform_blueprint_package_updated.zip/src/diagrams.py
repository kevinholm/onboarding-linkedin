from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'output' / 'diagrams'
OUT.mkdir(parents=True, exist_ok=True)

FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

COLORS = {
    'navy': (20, 42, 74),
    'blue': (49, 104, 173),
    'sky': (228, 238, 251),
    'teal': (36, 132, 142),
    'teal_bg': (229, 246, 248),
    'green': (56, 129, 84),
    'green_bg': (233, 246, 236),
    'orange': (214, 120, 28),
    'orange_bg': (255, 245, 230),
    'purple': (108, 78, 153),
    'purple_bg': (242, 237, 250),
    'red': (177, 42, 42),
    'red_bg': (252, 238, 238),
    'gray': (108, 117, 125),
    'light': (247, 249, 252),
    'line': (207, 216, 225),
    'dark': (43, 56, 64),
    'black': (0, 0, 0),
    'white': (255, 255, 255),
}


def font(size, bold=False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)


def new_canvas(title, subtitle=None, size=(2200, 1400)):
    img = Image.new('RGB', size, 'white')
    d = ImageDraw.Draw(img)
    d.text((60, 34), title, font=font(42, True), fill=COLORS['navy'])
    if subtitle:
        d.text((60, 90), subtitle, font=font(22), fill=COLORS['gray'])
    d.line((60, 128, size[0] - 60, 128), fill=COLORS['sky'], width=4)
    return img, d


def text_wrap(draw, text, fnt, max_width):
    words = str(text).split()
    lines, current = [], ''
    for word in words:
        trial = (current + ' ' + word).strip()
        if draw.textlength(trial, font=fnt) <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_multiline(draw, x, y, text, fnt, fill, max_width, line_gap=6):
    yy = y
    for line in text_wrap(draw, text, fnt, max_width):
        draw.text((x, yy), line, font=fnt, fill=fill)
        yy += fnt.size + line_gap
    return yy


def rounded(draw, box, fill, outline, radius=20, width=3):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def card(draw, x, y, w, h, title, lines, fill, outline, title_fill=None, bullet=True, body_size=22):
    rounded(draw, (x, y, x + w, y + h), fill, outline, radius=18, width=3)
    draw.text((x + 18, y + 14), title, font=font(28, True), fill=title_fill or COLORS['dark'])
    yy = y + 58
    for line in lines:
        if bullet:
            draw.ellipse((x + 20, yy + 8, x + 31, yy + 19), fill=outline)
            yy = draw_multiline(draw, x + 42, yy, line, font(body_size), COLORS['dark'], w - 58, line_gap=4) + 10
        else:
            yy = draw_multiline(draw, x + 18, yy, line, font(body_size), COLORS['dark'], w - 36, line_gap=4) + 10


def simple_box(draw, x, y, w, h, title, fill, outline, body=None, body_size=20, title_size=24):
    rounded(draw, (x, y, x + w, y + h), fill, outline, radius=16, width=3)
    draw.text((x + 14, y + 12), title, font=font(title_size, True), fill=COLORS['dark'])
    if body:
        draw_multiline(draw, x + 14, y + 46, body, font(body_size), COLORS['dark'], w - 28, line_gap=3)


def arrow(draw, x1, y1, x2, y2, fill=None, width=4, arrow_size=14):
    fill = fill or COLORS['gray']
    draw.line((x1, y1, x2, y2), fill=fill, width=width)
    ang = math.atan2(y2 - y1, x2 - x1)
    p1 = (x2, y2)
    p2 = (x2 - arrow_size * math.cos(ang - math.pi / 6), y2 - arrow_size * math.sin(ang - math.pi / 6))
    p3 = (x2 - arrow_size * math.cos(ang + math.pi / 6), y2 - arrow_size * math.sin(ang + math.pi / 6))
    draw.polygon([p1, p2, p3], fill=fill)


def dashed_arrow(draw, x1, y1, x2, y2, fill=None, width=3, dash=16, gap=10, arrow_size=14):
    fill = fill or COLORS['gray']
    dx, dy = x2 - x1, y2 - y1
    dist = math.hypot(dx, dy)
    if dist == 0:
        return
    ux, uy = dx / dist, dy / dist
    pos = 0
    while pos + dash < dist:
        sx, sy = x1 + ux * pos, y1 + uy * pos
        ex, ey = x1 + ux * (pos + dash), y1 + uy * (pos + dash)
        draw.line((sx, sy, ex, ey), fill=fill, width=width)
        pos += dash + gap
    arrow(draw, x1 + ux * max(pos - gap, 0), y1 + uy * max(pos - gap, 0), x2, y2, fill=fill, width=width, arrow_size=arrow_size)


def pill(draw, x, y, w, h, text, fill, outline):
    rounded(draw, (x, y, x + w, y + h), fill, outline, radius=h // 2, width=2)
    tw = draw.textlength(text, font=font(18, True))
    draw.text((x + (w - tw) / 2, y + 8), text, font=font(18, True), fill=COLORS['dark'])


def footer(draw, text, size):
    draw.line((60, size[1] - 56, size[0] - 60, size[1] - 56), fill=COLORS['sky'], width=3)
    draw.text((60, size[1] - 42), text, font=font(16), fill=COLORS['gray'])


def save(img, name):
    path = OUT / name
    img.save(path)
    print(path)


def diagram_01_platform_landscape():
    size = (2200, 1450)
    img, d = new_canvas('Executive Talent Platform - high level arkitektur', 'Kanaler, crawler/ingestion, automation-first platform, AI-lag, data og integrationer', size=size)

    # Top row sources/channels
    boxes = [
        ('Kandidatportal', ['Jobfeed, match, CV Studio, stakeholderkort', 'Ansogninger, NDA, onboarding, notifikationer'], COLORS['sky'], COLORS['blue']),
        ('Agent cockpit', ['Exception queue, review af AI-forslag, moedenoter', 'Prioritering, relationer og human override'], COLORS['teal_bg'], COLORS['teal']),
        ('Partnerportal', ['Brief-upload, anonym dialog, shortlist og NDA', 'Executive kandidatkort og processtatus'], COLORS['green_bg'], COLORS['green']),
        ('Crawler / discovery', ['Headhunter-sites, corporate career sites, ATS feeds', 'LinkedIn-signaler via compliant acquisition'], COLORS['orange_bg'], COLORS['orange']),
        ('Integrationer', ['Agent mailbox, tl;dv, e-sign, CRM, auth, analytics', 'ATS-partnere og dataleverandoerer'], COLORS['purple_bg'], COLORS['purple']),
    ]
    x_positions = [80, 500, 920, 1340, 1760]
    for x, (title, lines, fill, outline) in zip(x_positions, boxes):
        card(d, x, 165, 360, 190, title, lines, fill, outline, body_size=20)

    rounded(d, (80, 420, 2120, 940), COLORS['light'], COLORS['navy'], radius=24, width=4)
    d.text((100, 438), 'Kerneplatform, automation og workflowlag', font=font(30, True), fill=COLORS['navy'])

    modules = [
        ('Candidate Core', 'Master-CV, versioner, praferencer, samtykker', COLORS['sky'], COLORS['blue']),
        ('Opportunity Hub', 'Jobs, briefs, kilder, fortrolighed, processtatus', COLORS['teal_bg'], COLORS['teal']),
        ('Company Intelligence', 'Branche, ejerskab, skala, org-kontekst', COLORS['green_bg'], COLORS['green']),
        ('Matching Engine', 'Hard filters, semantik, context fit, explainability', COLORS['orange_bg'], COLORS['orange']),
        ('CV & Outreach Studio', 'AI-tilpasset CV, pitch, mails, redigering og release', COLORS['purple_bg'], COLORS['purple']),
        ('Stakeholder Graph', 'Forventet ansaettelsesudvalg, profiler og confidence', COLORS['red_bg'], COLORS['red']),
        ('Process & Case Mgmt', 'Automatiske workflows, tasks, SLA, exception queue og faseejerskab', COLORS['sky'], COLORS['blue']),
        ('Confidential Flows', 'Sealed briefs, anonym kandidat, NDA og reveal-kontrol', COLORS['teal_bg'], COLORS['teal']),
    ]
    coords = [(120, 500), (620, 500), (1120, 500), (1620, 500), (120, 705), (620, 705), (1120, 705), (1620, 705)]
    for (title, body, fill, outline), (x, y) in zip(modules, coords):
        simple_box(d, x, y, 430, 150, title, fill, outline, body=body, body_size=20)

    rounded(d, (80, 980, 2120, 1185), (250, 250, 252), COLORS['purple'], radius=22, width=4)
    d.text((100, 998), 'AI-, automation- og orkestreringslag', font=font(30, True), fill=COLORS['purple'])
    ai = [
        ('Extraction', 'Udtraekker struktur fra CV, brief, transskripter og websider'),
        ('Enrichment', 'Titelnormalisering, branche, lokation, ejerform og senioritet'),
        ('Ranking', 'Matchscore 0-100 og prioritering mod kandidater'),
        ('Generation', 'CV-forslag, pitch, outreach-beskeder, follow-ups og summaries'),
        ('Workflow Engine', 'Eventbus, koeer, regler, mailbox-orkestrering, notifikationer og SLA-styring'),
    ]
    ax = [120, 510, 900, 1290, 1680]
    for x, (title, body) in zip(ax, ai):
        simple_box(d, x, 1040, 350, 112, title, COLORS['purple_bg'] if title != 'Workflow Engine' else COLORS['teal_bg'], COLORS['purple'] if title != 'Workflow Engine' else COLORS['teal'], body=body, body_size=17, title_size=22)

    rounded(d, (80, 1225, 2120, 1390), (248, 250, 252), COLORS['green'], radius=22, width=4)
    d.text((100, 1240), 'Datafundament', font=font(28, True), fill=COLORS['green'])
    db = [
        ('PostgreSQL', 'Kerneobjekter, relationer, proces- og transaktionsdata'),
        ('pgvector', 'Embeddings for CV, jobs, noter og virksomhedskontekst'),
        ('Object storage', 'CV, briefs, transskripter, NDA og eksportfiler'),
        ('Search index', 'Filtrering og hurtige opslag i jobs og kandidater'),
        ('Audit & logs', 'Adgangsspor, AI-evidens, decisions og retention-historik'),
    ]
    dx = [120, 510, 900, 1290, 1680]
    for x, (title, body) in zip(dx, db):
        simple_box(d, x, 1282, 350, 90, title, COLORS['green_bg'], COLORS['green'], body=body, body_size=16, title_size=22)

    for x in [260, 680, 1100, 1520, 1940]:
        arrow(d, x, 355, x, 420, width=4)
    for x in [335, 835, 1335, 1835]:
        arrow(d, x, 940, x, 980, width=4)
    for x in [295, 685, 1075, 1465, 1855]:
        arrow(d, x, 1185, x, 1225, width=4)

    footer(d, 'Anbefalet levering: automation-first modulaar monolit i fase 1 med human-on-top agentlag og AI-workers som separat processing-lag.', size)
    save(img, '01_high_level_architecture.png')


def diagram_02_crawler_layer():
    size = (2200, 1450)
    img, d = new_canvas('Crawler- og opportunity intelligence-lag', 'Detaljeret pipeline fra kilder til normaliseret opportunity, AI-kategorisering og matchbar struktur', size=size)

    # Sources left
    left_titles = [
        ('Executive Search sites', 'Headhunter-hjemmesider, boutique-sites og public search listings', COLORS['orange_bg'], COLORS['orange']),
        ('Corporate career sites', 'Virksomheders egne karrieresider og investor/nyhedssektioner', COLORS['sky'], COLORS['blue']),
        ('ATS connectors', 'Greenhouse Job Board API, Lever Postings API, Teamtailor API/XML/webhooks', COLORS['green_bg'], COLORS['green']),
        ('Partner direct upload', 'Briefs, PDF, links og mail-forwarding fra samarbejdspartnere', COLORS['purple_bg'], COLORS['purple']),
        ('LinkedIn signal layer', 'Compliant acquisition: recruiter workflows, alerts, eksport, manuelle captures og klik-ud til eksterne career pages', COLORS['red_bg'], COLORS['red']),
    ]
    ys = [175, 355, 535, 715, 895]
    for y, (title, body, fill, outline) in zip(ys, left_titles):
        simple_box(d, 80, y, 430, 135, title, fill, outline, body=body, body_size=18, title_size=23)

    # Pipeline center
    pipeline = [
        ('Fetcher workers', 'Planlagte crawl jobs, robots-aware fetch, sitemap/opslagssider, HTML/API clients'),
        ('Raw capture store', 'Snapshot af HTML, JSON, feed-data og metadata pr. kilde og tidspunkt'),
        ('Normalize & dedupe', 'Canonical URL, virksomhedsnavn, jobtitel, posting-id, hash og dubletregler'),
        ('AI enrichment', 'Senioritet, funktion, branche, lokation, sprog, ejerkontekst og fortrolighedsniveau'),
        ('Taxonomy classifier', 'CEO -> Group CEO -> MD -> CXO -> EVP/SVP -> VP/Director -> Head of'),
        ('Opportunity assembler', 'Skaber standardiseret Opportunity-record med source-of-truth og confidence'),
    ]
    py = [180, 350, 520, 690, 860, 1030]
    for y, (title, body) in zip(py, pipeline):
        simple_box(d, 720, y, 560, 115, title, COLORS['light'], COLORS['navy'], body=body, body_size=18, title_size=24)

    # Right outputs/classification
    simple_box(d, 1450, 190, 630, 180, 'Outputfelt pr. rolle', COLORS['teal_bg'], COLORS['teal'], body='Titelnormalisering, niveau, funktion, branche, lokation, arbejdsmodel, virksomhedstype, ejerskab, Group/standalone, public/private, confidence og seneste verifikation.', body_size=18, title_size=24)
    simple_box(d, 1450, 415, 630, 220, 'Kildepolitik', COLORS['red_bg'], COLORS['red'], body='LinkedIn boer ikke vaere fundamenteret paa uautoriseret scraping. Brug i stedet godkendte integrationer, Recruiter/ATS flows, alerts, eksport og klik-ud til eksterne careersider. Personlige profiler boer kun bruges via lovlige/kontraktuelle workflows eller manuel research.', body_size=18, title_size=24)
    simple_box(d, 1450, 680, 630, 175, 'Match-ready artefakter', COLORS['green_bg'], COLORS['green'], body='1) Opportunity-record  2) Source snapshots  3) Embeddings  4) Evidens  5) Rekonstruerbar historik.', body_size=18, title_size=24)
    simple_box(d, 1450, 900, 630, 200, 'Videre til platformen', COLORS['purple_bg'], COLORS['purple'], body='Opportunity sendes til Matching Engine, Company Intelligence og Notifikation-workflows. Hvis score overstiger threshold, oprettes candidate-specific Match-records.', body_size=18, title_size=24)

    for y in [242, 422, 602, 782, 962]:
        arrow(d, 510, y, 720, y, width=4)
    for y in [295, 465, 635, 805, 975]:
        arrow(d, 1000, y + 0, 1000, y + 40, width=4)
    arrow(d, 1280, 1087, 1450, 1000, width=4)
    for y in [280, 515, 770, 1000]:
        arrow(d, 1280, y, 1450, y, width=4)

    # mini taxonomy pills
    names = ['CEO', 'Group CEO', 'Managing Director', 'CXO', 'EVP/SVP', 'VP/Director', 'Head of']
    px, py0 = 1500, 1120
    for i, name in enumerate(names):
        pill(d, px + (i % 3) * 185, py0 + (i // 3) * 58, 165, 42, name, COLORS['orange_bg'], COLORS['orange'])

    footer(d, 'Crawlerlaget boer designes som et separat ingestion-domane med tydelig source registry, scheduler, rate limits og replaybar historik.', size)
    save(img, '02_crawler_and_opportunity_intelligence.png')


def diagram_03_match_flow():
    size = (2200, 1400)
    img, d = new_canvas('Match, notifikation og ansogningsflow', 'Fra ny opportunity til AI-match, agentmail-outreach, follow-up og videre proces i platformen', size=size)

    flow = [
        ('Ny opportunity', 'Fra crawler, upload, partnerbrief eller kandidat-link'),
        ('Enrichment', 'Virksomhedsprofil, titel, senioritet, branche, lokation'),
        ('Candidate retrieval', 'Hent relevante kandidater via hard filters + semantisk recall'),
        ('Scoring engine', '0-100 score paa titel, funktion, branche, kontekst og geografi'),
        ('Threshold logic', '85+ prioritet A  |  70-84 prioritet B  |  55-69 adjacent  |  <55 lav'),
        ('Notifikation og outreach', 'Platform, agentmail og senere evt. SMS til kandidat, agent og eksterne modtagere'),
        ('Kandidatvalg', 'Accepter match / afvis match / snooze / giv feedback'),
        ('CV Studio', 'Generer AI-tilpasset CV, rediger, gem version og eksporter'),
        ('Case pipeline', 'Application -> interview -> assessment -> offer -> afslag/ansat'),
    ]
    y_positions = [180, 290, 400, 510, 620, 730, 840, 950, 1060]
    fills = [COLORS['sky'], COLORS['teal_bg'], COLORS['green_bg'], COLORS['orange_bg'], COLORS['purple_bg'], COLORS['red_bg'], COLORS['sky'], COLORS['teal_bg'], COLORS['green_bg']]
    outlines = [COLORS['blue'], COLORS['teal'], COLORS['green'], COLORS['orange'], COLORS['purple'], COLORS['red'], COLORS['blue'], COLORS['teal'], COLORS['green']]
    for y, (title, body), fill, outline in zip(y_positions, flow, fills, outlines):
        simple_box(d, 370, y, 900, 78, title, fill, outline, body=body, body_size=18, title_size=22)
    for y1, y2 in zip(y_positions, y_positions[1:]):
        arrow(d, 820, y1 + 78, 820, y2, width=4)

    # Right side details
    simple_box(d, 1430, 220, 650, 175, 'Matchscore - anbefalet vaegtning', COLORS['light'], COLORS['navy'], body='Titel/senioritet 25, funktionelt fit 20, branche 15, ejer- og transformationskontekst 10, skala/kompleksitet 10, geografi/sprog 10, timing/kompensation/mobilitet 10.', body_size=18, title_size=24)
    simple_box(d, 1430, 435, 650, 210, 'Feedback loop', COLORS['orange_bg'], COLORS['orange'], body='Afvisningsaarsager, manglende respons og manuel agent-feedback bruges til at justere ranking, kandidatpraeferencer og fremtidige threshold-regler. Alle modelinput og outputs logges som forklarlige artefakter.', body_size=18, title_size=24)
    simple_box(d, 1430, 690, 650, 220, 'Accepteret match', COLORS['green_bg'], COLORS['green'], body='Systemet opretter case, laeser relevant brief, foreslaar tilpasset CV, genererer stakeholder-hypotese og kan sende introduktion/outreach fra agentens mailadresse. Kandidat og agent ejer endelig frigivelse.', body_size=18, title_size=24)
    simple_box(d, 1430, 955, 650, 190, 'Afvist eller snoozed match', COLORS['red_bg'], COLORS['red'], body='Opportunity holdes i historik, men lukker aktivt workflow. Systemet lagrer aarsag, timing og evt. fremtidig reaktiveringsdato.', body_size=18, title_size=24)

    arrow(d, 1270, 658, 1430, 522, width=4)
    arrow(d, 1270, 880, 1430, 800, width=4)
    arrow(d, 1270, 880, 1430, 1048, width=4)

    footer(d, 'Alle kritiske overgange boer vaere eventdrevne: opportunity.created, match.created, message.sent, reply.received, sla.breached og process.stage.changed.', size)
    save(img, '03_matching_notification_application_flow.png')


def diagram_04_candidate_agent():
    size = (2200, 1400)
    img, d = new_canvas('Kandidat- og agentproces', 'Automation-first proces: platformen driver digitalt arbejde, agenten ejer relationer, godkendelser og undtagelser', size=size)

    # Left vertical candidate
    simple_box(d, 110, 220, 420, 145, 'Kandidatens masterprofil', COLORS['sky'], COLORS['blue'], body='Altomfattende CV, erfaring, praeferencer, samtykker, versioner, dokumenter og mobilitet.', body_size=20, title_size=25)
    simple_box(d, 110, 435, 420, 160, 'Moeder og intake', COLORS['teal_bg'], COLORS['teal'], body='Agenten afholder samtaler. tl;dv leverer transskript, notatkladde og action points.', body_size=20, title_size=25)
    simple_box(d, 110, 665, 420, 165, 'CV-forbedringsforslag', COLORS['green_bg'], COLORS['green'], body='AI finder nye resultater, scope, transformationscases og resultater der kan tilfoejes master-CV.', body_size=20, title_size=25)
    simple_box(d, 110, 900, 420, 190, 'Menneskelig godkendelse', COLORS['orange_bg'], COLORS['orange'], body='Kandidat accepterer, afviser eller redigerer hvert forslag. Ingen automatisk omskrivning af masterprofil.', body_size=20, title_size=25)

    # Middle journey
    simple_box(d, 780, 180, 620, 110, '1. Opportunity/match udloeser case', COLORS['purple_bg'], COLORS['purple'], body='Systemet opretter analyse, tasks, dokumentkladder og naeste handlinger.', body_size=19, title_size=24)
    simple_box(d, 780, 335, 620, 110, '2. AI-genereret CV + pitch', COLORS['purple_bg'], COLORS['purple'], body='Fremhaever relevant erfaring og udarbejder intro/pitch til rolle og modtager.', body_size=19, title_size=24)
    simple_box(d, 780, 490, 620, 110, '3. Agent review + kandidat finpudsning', COLORS['purple_bg'], COLORS['purple'], body='Tekst, prioritering, tone og dokumentform justeres og gemmes som ny version.', body_size=19, title_size=24)
    simple_box(d, 780, 645, 620, 110, '4. Outreach sendes fra agentmail', COLORS['purple_bg'], COLORS['purple'], body='Platformen sender fra agentens mailadresse, logger svar og holder styr paa kontakter og beslutninger.', body_size=19, title_size=24)
    simple_box(d, 780, 800, 620, 110, '5. Auto follow-up + eskalering', COLORS['purple_bg'], COLORS['purple'], body='Systemet nudger, klassificerer svar og notificerer agenten ved ingen respons eller varme leads.', body_size=19, title_size=24)
    simple_box(d, 780, 955, 620, 110, '6. Interview, udfald og onboarding', COLORS['purple_bg'], COLORS['purple'], body='Prep packs, stage updates, afslag, talentpool eller ansaettelse -> onboarding.', body_size=19, title_size=24)

    for y1, y2 in [(290, 335), (445, 490), (600, 645), (755, 800), (910, 955)]:
        arrow(d, 1090, y1, 1090, y2, width=4)

    # Right annotations
    simple_box(d, 1560, 250, 520, 175, 'Agentens styringspunkter', COLORS['light'], COLORS['navy'], body='Godkend ekstern kommunikation ved behov, prioriter varme cases, haandter ingen respons og relationstunge dialoger samt kommercielle valg.', body_size=18, title_size=23)
    simple_box(d, 1560, 480, 520, 200, 'Status og eskalering', COLORS['red_bg'], COLORS['red'], body='Alle replies, bookinger, manglende respons, SLA-brud og blockerede cases skaber in-app/email tasks til agenten med anbefalet next best action.', body_size=18, title_size=23)
    simple_box(d, 1560, 735, 520, 210, 'Interview + onboarding', COLORS['green_bg'], COLORS['green'], body='Prep packs, stakeholderbriefs, 100-dages plan, faste moeder og dokumenteret opfoelgning mellem kandidat og agent.', body_size=18, title_size=23)

    for y in [292, 515, 742, 980]:
        arrow(d, 530, y, 780, y, width=4)
    arrow(d, 1400, 856, 1560, 838, width=4)
    arrow(d, 1400, 566, 1560, 580, width=4)

    footer(d, 'Human-on-top automation: platformen driver digital eksekvering, mens agenten traeder ind ved approval, relationer og undtagelser.', size)
    save(img, '04_candidate_agent_process.png')


def diagram_05_confidential_partner():
    size = (2200, 1400)
    img, d = new_canvas('Fortrolige partner- og briefprocesser', 'Sealed briefs, anonym matching, NDA og kontrolleret reveal af kandidatidentitet', size=size)

    left = [
        ('Partner uploader brief', 'Brief, JD eller mandat uploades i partnerportalen.'),
        ('Sealed storage', 'Originalfil lagres krypteret. Kun uploader og eksplicit godkendte roller har adgang.'),
        ('AI-sanitized requirements', 'Systemet laver en redigeret, matchbar kravreprasentation uden at brede fortrolige detaljer ud.'),
        ('Anonym matching', 'Matchingmotoren finder relevante kandidater mod den sanitiserede model.'),
        ('Partner ser anonym shortlist', 'Partneren vurderer kandidater i executive anonymiseret format.'),
        ('NDA og kandidatvalg', 'NDA underskrives, kandidat og agent accepterer evt. dialog.'),
        ('Reveal + dialog', 'Identitet og fuldt brief frigives kontrolleret, og almindeligt procesflow overtager.'),
    ]
    y = 190
    for i, (title, body) in enumerate(left):
        fill = [COLORS['sky'], COLORS['red_bg'], COLORS['orange_bg'], COLORS['green_bg'], COLORS['purple_bg'], COLORS['teal_bg'], COLORS['sky']][i]
        outline = [COLORS['blue'], COLORS['red'], COLORS['orange'], COLORS['green'], COLORS['purple'], COLORS['teal'], COLORS['blue']][i]
        simple_box(d, 260, y + i * 145, 880, 95, f'{i+1}. {title}', fill, outline, body=body, body_size=19, title_size=22)
        if i < len(left) - 1:
            arrow(d, 700, y + i * 145 + 95, 700, y + (i + 1) * 145, width=4)

    right_boxes = [
        ('Adgangsmodel', 'Need-to-know rettigheder, audit log, break-glass adgang og fuld laeselog.', COLORS['light'], COLORS['navy']),
        ('Kandidatsikkerhed', 'Anonym executive card skal undgaa let deanonymisering via kombination af rolle, branche og geografi.', COLORS['green_bg'], COLORS['green']),
        ('NDA-haandtering', 'Standard NDA eller partnerens egen NDA. Proces maa stoppe automatisk indtil signatur foreligger.', COLORS['orange_bg'], COLORS['orange']),
        ('Videre forloeb', 'Efter reveal gaar casen over i samme interview-, stakeholder- og onboardingflow som oevrige cases.', COLORS['teal_bg'], COLORS['teal']),
    ]
    ry = [250, 470, 700, 930]
    for (title, body, fill, outline), yy in zip(right_boxes, ry):
        simple_box(d, 1370, yy, 620, 160, title, fill, outline, body=body, body_size=18, title_size=24)
    for yy in [330, 550, 780, 1010]:
        arrow(d, 1140, yy, 1370, yy, width=4)

    footer(d, 'Fortrolige briefs boer implementeres som et separat tillidsdomane med kryptering, masking og eksplcicit frigivelsesworkflow.', size)
    save(img, '05_confidential_partner_flow.png')


def diagram_06_services_data():
    size = (2200, 1450)
    img, d = new_canvas('Service- og datakort', 'Leverandoerklar oversigt over apps, backend-domainer, AI-workers, workflow, databaser og integrationer', size=size)

    # Apps row
    rounded(d, (80, 170, 2120, 300), COLORS['light'], COLORS['navy'], radius=20, width=4)
    d.text((100, 188), 'Frontend-apps', font=font(28, True), fill=COLORS['navy'])
    apps = [('Kandidat web', COLORS['sky'], COLORS['blue']), ('Agent web', COLORS['teal_bg'], COLORS['teal']), ('Partner web', COLORS['green_bg'], COLORS['green']), ('Admin/ops', COLORS['orange_bg'], COLORS['orange'])]
    ax = [250, 700, 1150, 1600]
    for x, (title, fill, outline) in zip(ax, apps):
        simple_box(d, x, 225, 260, 52, title, fill, outline, title_size=20)

    # API/services row
    rounded(d, (80, 350, 2120, 810), COLORS['light'], COLORS['purple'], radius=22, width=4)
    d.text((100, 368), 'Backend-domainer og platformservices', font=font(28, True), fill=COLORS['purple'])
    services = [
        ('API Gateway / BFF', 'Auth, session, rate limits, feature flags'),
        ('Identity & Access', 'RBAC, partner isolation, consent, SSO'),
        ('Candidate service', 'Profiler, CV-versioner, praeferencer'),
        ('Opportunity service', 'Jobs, briefs, dedupe, source registry'),
        ('Company service', 'Virksomheder, ejerskab, stakeholder graph'),
        ('Match service', 'Scoring, thresholds, explainability'),
        ('Case workflow service', 'Stage changes, tasks, SLAs, audit'),
        ('Doc generation service', 'CV, brief summary, exports, NDA packets'),
    ]
    sx = [120, 620, 1120, 1620, 120, 620, 1120, 1620]
    sy = [430, 430, 430, 430, 610, 610, 610, 610]
    colors = [(COLORS['sky'], COLORS['blue']), (COLORS['teal_bg'], COLORS['teal']), (COLORS['green_bg'], COLORS['green']), (COLORS['orange_bg'], COLORS['orange'])] * 2
    for (title, body), x, y, (fill, outline) in zip(services, sx, sy, colors):
        simple_box(d, x, y, 420, 120, title, fill, outline, body=body, body_size=18, title_size=22)

    # Side AI/workflow
    simple_box(d, 80, 850, 620, 190, 'AI-workers', COLORS['purple_bg'], COLORS['purple'], body='Parsing, enrichment, embeddings, ranking support, generation, guardrails og batch jobs. Koeres asynkront bag en queue.', body_size=19, title_size=24)
    simple_box(d, 790, 850, 620, 190, 'Workflow / event bus', COLORS['teal_bg'], COLORS['teal'], body='Temporal/Celery-lignende procesmotor. Events: crawl.completed, opportunity.created, match.created, message.sent, reply.received og sla.breached.', body_size=19, title_size=24)
    simple_box(d, 1500, 850, 620, 190, 'Notification service', COLORS['orange_bg'], COLORS['orange'], body='Agentmail, in-app alerts og senere SMS. Template engine, delegated send/send-as, thread tracking, retries og preference center.', body_size=19, title_size=24)

    # Data row
    rounded(d, (80, 1080, 2120, 1375), COLORS['light'], COLORS['green'], radius=22, width=4)
    d.text((100, 1098), 'Databaser og lagring', font=font(28, True), fill=COLORS['green'])
    data = [
        ('PostgreSQL', 'Transaktionel kerne og procesdata'),
        ('pgvector', 'Embeddings og similarity search'),
        ('Object storage', 'Filer, snapshots, eksporter, bilag'),
        ('OpenSearch', 'Facetteret soegning og kortvisninger'),
        ('Redis', 'Koeer, cache, throttling og sessionnaere data'),
        ('Audit store', 'Uforanderlig historik og compliance-spor'),
    ]
    dx = [120, 450, 780, 1110, 1440, 1770]
    for x, (title, body) in zip(dx, data):
        simple_box(d, x, 1160, 250, 150, title, COLORS['green_bg'], COLORS['green'], body=body, body_size=16, title_size=22)

    # External integrations strip right edge arrows
    for x in [380, 830, 1280, 1730]:
        arrow(d, x, 300, x, 350, width=4)
    for x in [390, 1100, 1810]:
        arrow(d, x, 810, x, 850, width=4)
    for x in [245, 575, 905, 1235, 1565, 1895]:
        arrow(d, x, 1040, x, 1080, width=4)

    footer(d, 'Teknisk anbefaling: tydelige domaener i en modulaar monolit, mens crawler, AI-workers, mailbox-orkestrering og notifikationer kan skaleres som separate workers.', size)
    save(img, '06_service_and_data_map.png')


def diagram_07_data_model():
    size = (2200, 1450)
    img, d = new_canvas('Kernedatamodel', 'Domaneobjekter og vigtigste relationer som udviklingspartneren kan starte schema-design ud fra', size=size)

    nodes = {
        'Candidate': (120, 240, 270, 110, COLORS['sky'], COLORS['blue'], 'Executive profil, praeferencer, samtykker'),
        'CandidateVersion': (120, 420, 270, 110, COLORS['sky'], COLORS['blue'], 'Master-CV og rolle-tilpassede versioner'),
        'Meeting': (120, 600, 270, 110, COLORS['teal_bg'], COLORS['teal'], 'Moeder, agenda, transcript-ref, status'),
        'Note': (120, 780, 270, 110, COLORS['teal_bg'], COLORS['teal'], 'Referat, aftaler, action points'),
        'Opportunity': (600, 240, 320, 110, COLORS['green_bg'], COLORS['green'], 'Job, brief eller dialogmulighed'),
        'Company': (1000, 240, 320, 110, COLORS['green_bg'], COLORS['green'], 'Virksomhed, ejerskab, skala, group'),
        'Brief': (600, 430, 320, 110, COLORS['orange_bg'], COLORS['orange'], 'Original brief, sanitiseret brief, source'),
        'Stakeholder': (1000, 430, 320, 110, COLORS['orange_bg'], COLORS['orange'], 'CEO, ejer, HR, recruiter, board'),
        'Match': (600, 620, 320, 110, COLORS['purple_bg'], COLORS['purple'], 'Candidate x Opportunity score og evidens'),
        'ApplicationCase': (1000, 620, 320, 110, COLORS['purple_bg'], COLORS['purple'], 'Pipeline, stages, interviews, owner'),
        'Partner': (1450, 240, 320, 110, COLORS['red_bg'], COLORS['red'], 'Headhunter, PE/VC/FO, virksomhed'),
        'NDA': (1450, 430, 320, 110, COLORS['red_bg'], COLORS['red'], 'Standard eller custom NDA, signaturstatus'),
        'Notification': (1450, 620, 320, 110, COLORS['light'], COLORS['navy'], 'Agentmail, inbound/outbound, reply status, SLA'),
        'OnboardingPlan': (1000, 820, 320, 110, COLORS['sky'], COLORS['blue'], '100-dages plan, moeder, aktiviteter'),
    }
    for title, (x, y, w, h, fill, outline, body) in nodes.items():
        simple_box(d, x, y, w, h, title, fill, outline, body=body, body_size=16, title_size=22)

    # relations
    def rel(a, b, label):
        ax, ay, aw, ah = nodes[a][0], nodes[a][1], nodes[a][2], nodes[a][3]
        bx, by, bw, bh = nodes[b][0], nodes[b][1], nodes[b][2], nodes[b][3]
        start = (ax + aw, ay + ah / 2) if ax < bx else (ax, ay + ah / 2)
        end = (bx, by + bh / 2) if ax < bx else (bx + bw, by + bh / 2)
        arrow(d, int(start[0]), int(start[1]), int(end[0]), int(end[1]), width=3)
        mx = (start[0] + end[0]) / 2
        my = (start[1] + end[1]) / 2 - 18
        pill(d, int(mx - 42), int(my - 6), 84, 32, label, COLORS['light'], COLORS['gray'])

    rel('Candidate', 'CandidateVersion', '1:N')
    rel('Candidate', 'Meeting', '1:N')
    rel('Meeting', 'Note', '1:N')
    rel('Opportunity', 'Company', 'N:1')
    rel('Opportunity', 'Brief', '1:N')
    rel('Company', 'Stakeholder', '1:N')
    rel('Candidate', 'Match', '1:N')
    rel('Opportunity', 'Match', '1:N')
    rel('Match', 'ApplicationCase', '0:1')
    rel('ApplicationCase', 'OnboardingPlan', '0:1')
    rel('Partner', 'Brief', '1:N')
    rel('Partner', 'NDA', '1:N')
    rel('ApplicationCase', 'Notification', '1:N')
    rel('ApplicationCase', 'Stakeholder', 'N:N')

    # extra arrows vertical
    arrow(d, 760, 350, 760, 430, width=3)
    arrow(d, 1160, 350, 1160, 430, width=3)
    arrow(d, 760, 540, 760, 620, width=3)
    arrow(d, 1160, 540, 1160, 620, width=3)
    arrow(d, 1160, 730, 1160, 820, width=3)
    arrow(d, 1610, 350, 1610, 430, width=3)
    arrow(d, 1610, 540, 1610, 620, width=3)

    # Legend
    simple_box(d, 1450, 820, 560, 165, 'Vigtige schema-noter', COLORS['light'], COLORS['navy'], body='Alle centrale objekter boer have immutable id, created_at, updated_at, source_id, confidence, access_scope og audit-trail reference. Dokumenter gemmes separat i object storage og bindes via metadata-tabeller.', body_size=18, title_size=24)
    simple_box(d, 1450, 1030, 560, 165, 'Versioneringsprincip', COLORS['orange_bg'], COLORS['orange'], body='Masterdata opdateres kontrolleret; AI-genererede artefakter lagres som afledte versioner med relation til kilde (brief, moede, transcript, manual edit).', body_size=18, title_size=24)

    footer(d, 'Udviklingspartneren kan bruge modellen som basis for domain-driven design, databasedesign og API-kontrakter.', size)
    save(img, '07_core_data_model.png')


def main():
    diagram_01_platform_landscape()
    diagram_02_crawler_layer()
    diagram_03_match_flow()
    diagram_04_candidate_agent()
    diagram_05_confidential_partner()
    diagram_06_services_data()
    diagram_07_data_model()


if __name__ == '__main__':
    main()
