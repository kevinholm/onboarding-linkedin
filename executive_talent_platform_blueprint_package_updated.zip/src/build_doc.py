from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.section import WD_ORIENTATION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path
import datetime as dt

BASE = Path(__file__).resolve().parents[1]
DIAG = BASE / 'output' / 'diagrams'
OUT = BASE / 'output'
OUT.mkdir(parents=True, exist_ok=True)

ACCENT = RGBColor(20, 42, 74)
TEXT = RGBColor(44, 56, 64)
GRAY = RGBColor(106, 117, 125)
LIGHT_BLUE = 'EAF1FB'
LIGHT_GREEN = 'EDF6EF'
LIGHT_ORANGE = 'FFF4E5'
LIGHT_PURPLE = 'F1ECFA'
LIGHT_RED = 'FBEDEE'
LIGHT_TEAL = 'E8F5F6'
BORDER = 'D6DEE8'


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)


def set_cell_border(cell, color='D0D7DE', size='8'):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right'):
        tag = 'w:%s' % edge
        element = tcBorders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            tcBorders.append(element)
        element.set(qn('w:val'), 'single')
        element.set(qn('w:sz'), size)
        element.set(qn('w:space'), '0')
        element.set(qn('w:color'), color)


def set_doc_language(doc, lang='da-DK'):
    styles = doc.styles
    for style_name in ['Normal', 'Title', 'Heading 1', 'Heading 2', 'Heading 3']:
        style = styles[style_name]
        rPr = style.element.get_or_add_rPr()
        lang_el = rPr.find(qn('w:lang'))
        if lang_el is None:
            lang_el = OxmlElement('w:lang')
            rPr.append(lang_el)
        lang_el.set(qn('w:val'), lang)
        lang_el.set(qn('w:eastAsia'), lang)
        lang_el.set(qn('w:bidi'), lang)


def make_styles(doc):
    styles = doc.styles
    styles['Normal'].font.name = 'Aptos'
    styles['Normal'].font.size = Pt(10.5)
    styles['Normal'].font.color.rgb = TEXT

    styles['Title'].font.name = 'Aptos Display'
    styles['Title'].font.size = Pt(27)
    styles['Title'].font.bold = True
    styles['Title'].font.color.rgb = ACCENT

    for name, size in [('Heading 1', 18), ('Heading 2', 14), ('Heading 3', 12)]:
        style = styles[name]
        style.font.name = 'Aptos Display'
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = ACCENT


def set_landscape(section):
    section.orientation = WD_ORIENTATION.LANDSCAPE
    section.page_width, section.page_height = section.page_height, section.page_width
    section.top_margin = Inches(0.55)
    section.bottom_margin = Inches(0.55)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)
    section.header_distance = Inches(0.25)
    section.footer_distance = Inches(0.25)


def add_header_footer(doc):
    for section in doc.sections:
        header = section.header
        p = header.paragraphs[0]
        p.text = 'Executive Talent Platform - loesningsblueprint'
        p.style = doc.styles['Normal']
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.runs[0].font.size = Pt(8)
        p.runs[0].font.color.rgb = GRAY
        footer = section.footer
        p = footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.text = 'Udarbejdet til udviklingspartner - side '
        run = p.add_run()
        fld1 = OxmlElement('w:fldChar')
        fld1.set(qn('w:fldCharType'), 'begin')
        instr = OxmlElement('w:instrText')
        instr.set(qn('xml:space'), 'preserve')
        instr.text = ' PAGE '
        fld2 = OxmlElement('w:fldChar')
        fld2.set(qn('w:fldCharType'), 'end')
        run._r.append(fld1)
        run._r.append(instr)
        run._r.append(fld2)
        for r in p.runs:
            r.font.size = Pt(8)
            r.font.color.rgb = GRAY


def add_title_page(doc):
    p = doc.add_paragraph()
    p.style = doc.styles['Title']
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.add_run('Executive Talent Platform\nLoesningsblueprint')

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run('Automation-first operating model, high level arkitektur, crawler-/ingestion-lag, procesflows, datamodel og udviklingshaandoff')
    r.font.size = Pt(15)
    r.font.color.rgb = GRAY

    table = doc.add_table(rows=2, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    widths = [2.6, 3.1, 3.7]
    heads = ['Formaal', 'Operating model', 'Vigtig designbeslutning']
    bodies = [
        'Byg et executive talent operating system og ikke kun et matching-tool. Platformen skal styre discovery, match, dokumenter, outreach, dialog, NDA og onboarding i et samlet procesflow.',
        'Automatiser saa meget af agentens digitale arbejde som muligt. Platformen udfoerer default discovery, analyser, dokumentudkast, outreach, opfoelgning og case-opdatering, mens agenten er human control layer for relationer, prioritering og undtagelser.',
        'Ekstern outreach kan udsendes af platformen, men skal ske fra agentens mailadresse via delegated send/send-as. Svar, manglende respons og kritiske haendelser skal skabe agentnotifikationer, tasks og eskaleringer.'
    ]
    for i, cell in enumerate(table.rows[0].cells):
        cell.width = Inches(widths[i])
        cell.text = heads[i]
        set_cell_shading(cell, LIGHT_BLUE if i == 0 else LIGHT_PURPLE if i == 1 else LIGHT_ORANGE)
        set_cell_border(cell, BORDER)
        for p in cell.paragraphs:
            for r in p.runs:
                r.font.bold = True
                r.font.size = Pt(10.5)
                r.font.color.rgb = ACCENT
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for i, cell in enumerate(table.rows[1].cells):
        cell.width = Inches(widths[i])
        cell.text = bodies[i]
        set_cell_border(cell, BORDER)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for p in cell.paragraphs:
            for r in p.runs:
                r.font.size = Pt(10)
                r.font.color.rgb = TEXT

    doc.add_paragraph()
    p = doc.add_paragraph()
    r = p.add_run('Denne pakke indeholder:')
    r.bold = True
    r.font.size = Pt(12)
    r.font.color.rgb = ACCENT
    for item in [
        '7 grafiske arkitektur- og procesdiagrammer',
        'Automation-first operating model for agentrollen',
        'Outreach, opfoelgning og eskalering sendt fra agentens mailadresse',
        'Anbefalet crawler-/ingestion-arkitektur med AI-kategorisering fra CEO til Head of',
        'Service- og datakort samt kernedatamodel',
        'Anbefalet build plan og integrationsnoter til udviklingspartneren',
    ]:
        p = doc.add_paragraph(style=doc.styles['Normal'])
        p.style = doc.styles['Normal']
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3)
        p.add_run('• ' + item)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run('Version: 1.1  |  Dato: ' + dt.date.today().isoformat())
    r.font.size = Pt(10)
    r.font.color.rgb = GRAY
    doc.add_page_break()


def add_para(doc, text, style='Normal', size=None, color=None, bold=False, space_after=6):
    p = doc.add_paragraph(style=doc.styles[style] if isinstance(style, str) else style)
    r = p.add_run(text)
    if size:
        r.font.size = Pt(size)
    if color:
        r.font.color.rgb = color
    if bold:
        r.bold = True
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_image_page(doc, heading, body, image_name, caption=None, width=8.8):
    add_para(doc, heading, style='Heading 1', space_after=3)
    add_para(doc, body, style='Normal', size=10.5, color=TEXT, space_after=8)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(DIAG / image_name), width=Inches(width))
    doc.add_page_break()


def add_table(doc, heading, intro, headers, rows, widths=None, fills=None):
    add_para(doc, heading, style='Heading 1', space_after=3)
    if intro:
        add_para(doc, intro, style='Normal', size=10.5, space_after=8)
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    if widths is None:
        widths = [9.4 / len(headers)] * len(headers)
    for j, cell in enumerate(table.rows[0].cells):
        cell.width = Inches(widths[j])
        cell.text = headers[j]
        set_cell_shading(cell, fills[j] if fills else LIGHT_BLUE)
        set_cell_border(cell, BORDER)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for p in cell.paragraphs:
            for r in p.runs:
                r.bold = True
                r.font.size = Pt(10)
                r.font.color.rgb = ACCENT
    for i, row in enumerate(rows, start=1):
        for j, cell in enumerate(table.rows[i].cells):
            cell.width = Inches(widths[j])
            cell.text = row[j]
            set_cell_border(cell, BORDER)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if i % 2 == 0:
                set_cell_shading(cell, 'FAFBFC')
            for p in cell.paragraphs:
                for r in p.runs:
                    r.font.size = Pt(9.4)
                    r.font.color.rgb = TEXT
    doc.add_paragraph()


def add_summary_section(doc):
    add_para(doc, 'Arkitekturbeskrivelse i kort form', style='Heading 1', space_after=3)
    add_para(doc, 'Platformen boer bygges som et executive talent operating system med tre frontdoere (kandidat, agent, partner), et separat discovery/crawler-domane, en samlet kerneplatform for match og processtyring samt et automation-first AI- og workflowlag.', size=10.8)
    add_para(doc, 'Default-reglen boer vaere, at platformen udfoerer alt digitalt standardarbejde automatisk: ingestion, job- og virksomhedsanalyser, match, dokumentforslag, outreach, opfoelgning, statusopdateringer og rapportering. Menneskelig agent fungerer som relationsejer, godkender, optimerer og tager over i undtagelser.', size=10.8)
    add_para(doc, 'Alle eksterne outreach-flows boer kunne sende fra agentens mailadresse via delegated send/send-as, saaledes at markedet svarer tilbage til et rigtigt menneske. Naar der ikke kommer respons, naar en strategisk relation svarer, eller naar en case blokerer, skal platformen notificere agenten og skabe en tydelig next-best-action.', size=10.8)
    headers = ['Domaene', 'Hvad det ejer', 'Hvorfor det er vigtigt']
    rows = [
        ['Discovery / crawler', 'Kilder, fetch jobs, snapshots, normalisering, dubletkontrol, AI-kategorisering', 'Giver et stabilt og replaybart opportunity-fundament uanset om kilden er ATS, headhunter-site eller upload'],
        ['Core platform', 'Kandidat, opportunity, virksomhed, match, case, dokumenter, NDA, onboarding', 'Holder hele business-processen i samme datamodel i stedet for at sprede logik i flere siloer'],
        ['AI & workflow', 'Extraction, enrichment, ranking, generation, outreach, opfoelgning, regler og notifikationer', 'Goer systemet effektivt ved at automatisere agentens digitale standardarbejde uden at lade modellen vaere selve systemet'],
        ['Agent control layer', 'Approval flows, exception queue, prioritering, relationer og manuel overstyring', 'Sikrer at agenten kun bruger tid der, hvor menneskelig judgement, netvaerk og timing skaber reel vaerdi'],
        ['Trust & governance', 'RBAC, sealed briefs, audit, consent, retention, explainability', 'Noedvendigt fordi platformen arbejder med executives, fortrolige briefs og persondata'],
    ]
    add_table(doc, 'Kerneprincipper', '', headers, rows, widths=[1.9, 3.7, 3.7], fills=[LIGHT_BLUE, LIGHT_TEAL, LIGHT_ORANGE])


def add_source_policy_section(doc):
    headers = ['Kildetype', 'Anbefalet acquisition-mode', 'Risiko / note', 'Prioritet']
    rows = [
        ['Headhunter-hjemmesider', 'Egen crawler paa offentlige search/job-sider', 'Lav til moderat risiko. Krav: robots-aware fetch, rate limits, source registry og HTML snapshots.', 'Hoj'],
        ['Corporate karrieresider', 'Egen crawler eller sitemap-baseret discovery', 'Lav til moderat risiko. God kilde til strukturerede jobs og virksomhedscontext.', 'Hoj'],
        ['Greenhouse', 'Job Board API / offentlig board data', 'Offentlig GET-adgang til public jobs. Velegnet som primaer ATS-kilde.', 'Hoj'],
        ['Lever', 'Postings API / hosted jobs pages', 'Public job postings er tilgaengelige; public jobs kan i praksis scrapes af tredjepart, men brug helst API/feed.', 'Hoj'],
        ['Teamtailor', 'API, XML-feed eller webhook/integration', 'Kraver oftest API-noegle eller partner-/jobboard-flow. God som strategisk ATS-connector.', 'Hoj'],
        ['Partner direct upload', 'Portal-upload, mail-forwarding og brief ingestion', 'Lav teknisk risiko og meget hoej forretningsvaerdi.', 'Hoj'],
        ['LinkedIn jobs/company pages', 'Compliant signal acquisition, alerts, approved integrations, manuelle captures og klik-ud til eksterne careersider', 'Boer ikke baseres paa uautoriseret scraping/crawlers. Brug LinkedIn som signalspor og ikke som central kildebase.', 'Mellem'],
        ['LinkedIn personlige profiler', 'Manuel research eller kontraktuel/godkendt integration', 'Hoej risiko ift. terms, privatliv og kontolukning. Boer ikke vaere crawler-fundament.', 'Lav'],
    ]
    add_table(doc, 'Kildepolitik og crawlerstrategi', 'Tabellen er vigtig for udviklingspartnerens beslutning om hvilke connectors der bygges som foerste fase, og hvilke der kun bruges som signal- eller researchspor.', headers, rows, widths=[1.9, 3.25, 3.45, 1.0], fills=[LIGHT_BLUE, LIGHT_GREEN, LIGHT_ORANGE, LIGHT_PURPLE])


def add_automation_model_section(doc):
    headers = ['Agentopgave', 'Default systemadfaerd', 'AI-understoettelse', 'Agentens rolle']
    rows = [
        ['Job/brief ingestion', 'Systemet henter opslag, snapshots, parser originalkilde og gemmer en struktureret version automatisk.', 'Extraction, klassifikation, dubletkontrol og company enrichment.', 'Traeder kun til ved fejl, fortrolighed, uklar kilde eller manuel prioritering.'],
        ['Job- og virksomhedsanalysen', 'Genereres automatisk ved ny opportunity og ved stoerre aendringer i opslag/brief.', 'Must-have/nice-to-have, stakeholder-hypotese, company intelligence og risikoindikatorer.', 'Finjusterer vinkling paa udvalgte eller high-stakes cases.'],
        ['Match og positionering', 'Systemet opretter scored matches, foreslaar pitch og anbefaler next best action.', 'Ranking, gap-analyse, argumentbank og adjacent-role logik.', 'Overstyrer prioritet naar relationer, markedskendskab eller timing taler for det.'],
        ['Dokumenter og materiale', 'CV-version, intro, application notes og prep-pack genereres som udgangspunkt automatisk.', 'Generation, diff-visning, forklaringer og versionering.', 'Godkender ekstern brug og haandterer det sidste kvalitetstjek ved vigtige processer.'],
        ['Outreach og follow-up', 'Beskeder sendes fra agentens mailadresse, replies logges, og standardopfoelgning starter automatisk.', 'Tonevalg, personalisering, svarklassifikation og anbefalet naeste besked.', 'Traeder til ved ingen respons, varme leads, relationstunge dialoger og forhandling.'],
        ['Procesopfoelgning', 'Case, SLA, tasks, stage-skift og rapportering opdateres automatisk.', 'Next-best-action, risikosignaler, resumeer og notifikationer.', 'Tager action ved blokeringer, konflikter, fortrolige forhold og kommercielle valg.'],
    ]
    add_table(doc, 'Automatiseringsmodel for agentrollen', 'Maalbilledet er et human-on-top operating model: platformen haandterer det gentagelige digitale arbejde, mens agenten traeder ind der, hvor relationer, judgement og timing betyder mest.', headers, rows, widths=[1.85, 3.05, 2.9, 1.75], fills=[LIGHT_BLUE, LIGHT_GREEN, LIGHT_PURPLE, LIGHT_ORANGE])


def add_outreach_section(doc):
    headers = ['Trigger', 'Systemhandling', 'Notifikation til agent', 'Forventet menneskelig aktion']
    rows = [
        ['Ny godkendt case', 'Systemet opretter outreach-sekvens, klargor besked og kan sende fra agentens mailadresse.', 'Agent ser preview, status og planlagt timing i cockpit.', 'Optional review paa high-stakes cases eller ved manuel release policy.'],
        ['Ingen respons inden SLA', 'Platformen sender automatisk naeste nudge eller parkerer udsendelse efter regel.', 'Agent faar task med kandidat, modtager, historik og anbefalet handling.', 'Agent tager personlig kontakt eller justerer vinkel og kanal.'],
        ['Positiv respons eller booking', 'Reply klassificeres, case opdateres, og prep-pack genereres automatisk.', 'Agent faar instant notifikation med resume og naeste forslag.', 'Agent overtager dialog, relation og moedeforberedelse.'],
        ['Negativ respons / afslag', 'Systemet logger aarsag, opdaterer signaler og foreslaar evt. svar eller talentpooling.', 'Agent notificeres kun ved strategisk kontakt, vigtig laering eller manuel regel.', 'Agent vurderer om relationen skal holdes varm eller lukkes ned.'],
        ['Fortrolig eller usikker case', 'Automation bremses, og systemet kraever review foer videre udsendelse.', 'Agent faar prioriteret alert med begrundelse og risikomarkering.', 'Agent beslutter om workflow skal fortsaette, omskrives eller stoppes.'],
    ]
    add_table(doc, 'Outreach, notifikationer og eskaleringer', 'Kommunikationsmotoren skal vaere eventdrevet og by design koblet til agentens identitet. Markedet skal opleve et rigtigt menneske som afsender, mens platformen styrer timing, tracking, SLA og opfoelgning.', headers, rows, widths=[1.7, 3.2, 2.2, 2.25], fills=[LIGHT_PURPLE, LIGHT_BLUE, LIGHT_TEAL, LIGHT_ORANGE])


def add_stack_section(doc):
    headers = ['Lag', 'Anbefaling', 'Noter til udviklingspartner']
    rows = [
        ['Frontend', 'Next.js / React', 'Tre apps eller tre tydelige app-domainer: kandidat, agent, partner. Delte design tokens og role-based views.'],
        ['Backend', 'NestJS eller tilsvarende typed backend', 'Egnet til modulaar monolit, event publishing og tydelige API-kontrakter.'],
        ['AI-workers', 'Python/FastAPI workers', 'Separat queue-baseret behandling til extraction, enrichment, ranking support, generation og reply classification.'],
        ['DB', 'PostgreSQL + pgvector', 'Transaktionel kerne kombineret med semantisk retrieval.'],
        ['Soegning', 'OpenSearch/Elasticsearch', 'Til facetter, kandidatkort, joblister og hurtige filtre.'],
        ['Fil-lagring', 'S3-kompatibelt object storage', 'Gem CV, briefs, snapshots, transskripter, NDA og eksportfiler.'],
        ['Workflow', 'Temporal eller tilsvarende', 'Godt til lange forloeb, retries, notifikationer, follow-up sekvenser og idempotente processer.'],
        ['Mailbox integration', 'Microsoft 365 / Google Workspace', 'Understoet delegated send/send-as, inbound sync, thread tracking og routing af svar til de rigtige cases.'],
        ['Notifikation', 'Postmark/SendGrid + in-app + senere SMS', 'Start med email og in-app. Laeg SMS bag feature flag til senere.'],
    ]
    add_table(doc, 'Anbefalet teknologistak', 'Stacken er ikke eneste mulighed, men den matcher behovet for hurtig time-to-market, tydelig udvidelsesvej og en automation-first agentmodel.', headers, rows, widths=[1.55, 2.75, 5.0], fills=[LIGHT_BLUE, LIGHT_TEAL, LIGHT_GREEN])


def add_roadmap_section(doc):
    headers = ['Fase', 'Leverance', 'Resultat']
    rows = [
        ['Fase 1', 'Kandidatportal, agent cockpit, master-CV, company intelligence, match engine v1, manuelle jobs/uploads, delegeret mailudsendelse, auto-opfoelgning, emailnotifikationer og caseautomations', 'Platformen kan modtage muligheder, matche kandidater, generere materiale, sende outreach fra agentens mailadresse og styre cases end-to-end.'],
        ['Fase 2', 'Crawler workers, ATS connectors, partnerportal, anonym executive card, NDA-flow, sealed briefs, stakeholder graph v1, reply-klassifikation og exception queue', 'Discovery-motoren og partnerprocessen bliver operative og skalerbare, og agenten faar et egentligt human-on-top control layer.'],
        ['Fase 3', 'Feedback-baseret ranking, benchmarking, flere integrationsspor, avanceret SLA/orchestration og 100-dages onboardingmodul', 'Systemet gaar fra operationelt rekrutteringssystem til fuldt talent operating system med kontinuerlig laering.'],
    ]
    add_table(doc, 'Anbefalet leveranceplan', 'Udviklingspartneren boer estimere hver fase som separate work packages med egne demo-kriterier, datamigrationer og acceptance checks.', headers, rows, widths=[1.2, 5.0, 3.2], fills=[LIGHT_PURPLE, LIGHT_BLUE, LIGHT_GREEN])


def add_references(doc):
    add_para(doc, 'Eksterne noter og referencer', style='Heading 1', space_after=3)
    add_para(doc, 'Nedenstaaende referencer er inkluderet fordi de paavirker, hvordan crawler- og integrationslaget boer designes i praksis.', size=10.5)
    refs = [
        'LinkedIn Help: Prohibited software and extensions - beskriver, at crawlers/bots/plug-ins der scraper eller automatiserer aktivitet paa LinkedIn ikke er tilladt.',
        'LinkedIn Help / Microsoft Learn: Recruiter System Connect (RSC) - viser at LinkedIn Recruiter integrationer er bundet til udvalgte ATS-partnere og Recruiter-licenser.',
        'LinkedIn Microsoft Learn: Job Posting API - beskriver at API-adgang er for godkendte partnere, og at nye partnerskaber ikke generelt optages frit.',
        'Greenhouse Developer Docs: Job Board API - offentlig adgang til published jobs og application-endpoint med auth.',
        'Lever Postings API - offentlig dokumentation for published job postings og custom application flow.',
        'Teamtailor Job Board API / XML / API docs - dokumenterer API, XML-feed og webhook/integrationsmuligheder.',
        'tl;dv Integrations - viser support for Zoom, Google Meet og Microsoft Teams samt integrationer mod andre systemer.',
    ]
    for item in refs:
        p = doc.add_paragraph(style=doc.styles['Normal'])
        p.paragraph_format.left_indent = Inches(0.2)
        p.paragraph_format.space_after = Pt(4)
        p.add_run('• ' + item)


def build():
    doc = Document()
    set_landscape(doc.sections[0])
    set_doc_language(doc)
    make_styles(doc)
    add_header_footer(doc)
    add_title_page(doc)
    add_summary_section(doc)
    add_image_page(doc, 'High level arkitektur', 'Dette billede er det bedste sted at starte med en udviklingspartner. Det viser frontdoere, discovery/crawler-lag, kerneplatform, automation-first AI-lag og datafundament i samme billede.', '01_high_level_architecture.png', 'Figur 1. Samlet high level arkitektur for platformen.', width=8.8)
    add_image_page(doc, 'Crawler- og opportunity intelligence-lag', 'Her er discovery-motoren detaljeret. Den goer det tydeligt, at offentlige ATS-feeds og eksterne karrieresider er primaere kilder, mens LinkedIn behandles som signalspor og ikke som blind scraping-kilde.', '02_crawler_and_opportunity_intelligence.png', 'Figur 2. Crawler pipeline, AI-berigelse og output til matchbare opportunities.', width=8.8)
    add_image_page(doc, 'Match-, notifikations- og ansogningsflow', 'Dette flow viser, hvordan en ny opportunity bliver til candidate-specific matches, hvordan kandidat og agent bliver orienteret, og hvordan automatiseret outreach, follow-up og menneskelig eskalering fodrer tilbage til platformen.', '03_matching_notification_application_flow.png', 'Figur 3. Matchscore, threshold-logik, notifikationer og case-oprettelse.', width=8.8)
    add_image_page(doc, 'Kandidat- og agentproces', 'Processen viser, hvordan masterprofil, moeder, AI-berigelse, mailudsendelser, follow-ups og menneskelig exception handling spiller sammen gennem hele forloebet.', '04_candidate_agent_process.png', 'Figur 4. Kandidatens og agentens operative proces gennem hele forloebet.', width=8.8)
    add_image_page(doc, 'Fortrolige partner- og briefprocesser', 'Dette er en noegleproces, hvis I vil arbejde med search-butikker, PE/VC/FO og virksomheder der har fortrolige mandater. Arkitekturen bygger paa sealed storage, anonym matching og kontrolleret reveal.', '05_confidential_partner_flow.png', 'Figur 5. Fortrolige briefs, anonym shortlist, NDA og kontrolleret reveal.', width=8.8)
    add_image_page(doc, 'Service- og datakort', 'Diagrammet er rettet mod udviklingspartneren og kan bruges som udgangspunkt for repos, services, mailbox-integration, deployment og ansvarsdeling mellem teams.', '06_service_and_data_map.png', 'Figur 6. Servicegrupper, AI-workers, workflow og datalag.', width=8.8)
    add_image_page(doc, 'Kernedatamodel', 'Datamodellen er ikke endelig, men den giver en praktisk start paa schema-design, API-kontrakter og eventnavngivning.', '07_core_data_model.png', 'Figur 7. Kernedatamodel og relationer mellem de vigtigste objektklasser.', width=8.8)
    add_source_policy_section(doc)
    add_automation_model_section(doc)
    doc.add_page_break()
    add_outreach_section(doc)
    doc.add_page_break()
    add_stack_section(doc)
    add_roadmap_section(doc)
    add_references(doc)
    out = OUT / 'executive_talent_platform_solution_blueprint.docx'
    doc.save(out)
    print(out)


if __name__ == '__main__':
    build()
