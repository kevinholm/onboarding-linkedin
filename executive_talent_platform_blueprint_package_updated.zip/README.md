# Executive Talent Platform - developer handoff package

## Included

- `output/executive_talent_platform_solution_blueprint.docx`
- `output/rendered/executive_talent_platform_solution_blueprint.pdf`
- `output/diagrams/*.png`
- `src/diagrams.py` - source that generated the diagrams
- `src/build_doc.py` - source that generated the document

## What the package covers

- High level architecture for candidate, agent and partner portals
- Automation-first operating model where the platform handles most digital agent work by default
- Human-on-top control layer for approvals, relationships, escalations and exception handling
- Dedicated crawler / ingestion domain
- Opportunity intelligence and AI categorisation from CEO to Head of
- Matching, notification, outreach, reply-tracking and application flow
- Candidate/agent process flow with delegated mail sending and no-response escalation
- Confidential partner / NDA flow
- Service and data map
- Core data model
- Source policy and implementation notes for ATS, headhunter sites and LinkedIn-related acquisition

## Important product/engineering notes

- LinkedIn should be treated as a signal and integration track, not as a blind scraping foundation. The architecture in the document therefore recommends compliant acquisition modes such as approved integrations, Recruiter/ATS workflows, alerts, exports, manual capture and click-through to external career pages.
- Outreach messages should be sent from the agent's own mailbox identity via delegated send/send-as or an equivalent enterprise pattern, so that replies go back to a real human while the platform handles orchestration, tracking and escalation.
- The target state is that the platform supports as much as possible digitally and automatically, while the human agent remains the owner of relationship-heavy moments, manual optimisation and exception resolution.
